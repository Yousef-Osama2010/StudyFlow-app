# StudyFlow: keep only Android entry points.
-keep class com.yousefosama.studyflow.MainActivity { *; }
